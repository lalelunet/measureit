#ifndef MATCH_H
#define MATCH_H

extern int match(const char *,const char *,unsigned int);

#endif
